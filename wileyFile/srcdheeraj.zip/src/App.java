import java.sql.*;
import java.util.Scanner;

import controllers.CityController;
import controllers.CountryController;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		try {
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			CityController cities = new CityController();
//			cities.create();
//			cities.read();
//			cities.read();
//			cities.update();
//			cities.readOne();
//			cities.delete();
//		} catch (Exception e) {
//			System.out.println("Some error occurred in the application " + e);
//		}
		try {
			CountryController countries = new CountryController();
			countries.create();
			countries.read();
			countries.read();
			countries.update();
			countries.readOne();
			//countries.delete();
		} catch (Exception e) {
			System.out.println("Some error occurred in the application " + e);
		}
	}
}
