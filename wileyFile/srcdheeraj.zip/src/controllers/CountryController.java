package controllers;

import java.sql.ResultSet;
import models.Country;

/**
 * Controller class for operations on country table
 */
public class CountryController {
	/**
	 * Retrieves the details of all the countries and prints them
	 */
	public void read() {
		ResultSet result = Country.fetchAllCountryDetails();
		Country.printCountryDetails(result);
	}

	/**
	 * Retrieves the details of the country corresponding to the id
	 */
	public void readOne() {
		ResultSet result = Country.fetchCountryDetailsByCode("ABW");
		Country.printCountryDetails(result);
	}

	public void create() {
		int rowsAffected = Country.insertCountry("NEW", "New Country", "Europe", "Eastern Asia", 384384.00f, 1998,
				73248237, 67.3f, 785.00f, 729.0f, "New Count", "Democratic", "John Doe", 2984, "NW");
		System.out.println(rowsAffected + " records were inserted");
	}

	public void update() {
		int[] rowsAffected = Country.updateCountry("Latest Country", "NEW");
		for (int i = 1; i < rowsAffected.length; i++) {
			System.out.println(i + " records were updated");

		}
	}                     

	public void delete() {
		int rowsAffected = Country.deleteCountry("NEW");
		System.out.println(rowsAffected + " records were deleted");

	}
}
