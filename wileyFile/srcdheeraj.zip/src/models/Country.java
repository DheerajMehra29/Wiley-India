package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import helpers.ConnectionManager;

public class Country {
	private static final Connection connection = ConnectionManager.getConnection();

	public static void printCountryDetails(ResultSet result) {
		if (result != null) {
			try {
				if (!result.next()) {
					System.out.println("Empty set!");
				} else {
					do {
						String Code = result.getString(1);
						String Name = result.getString(2);
						String Continent = result.getString(3);
						String Region = result.getString(4);
						Float SurfaceArea = result.getFloat(5);
						int IndepYear = result.getInt(6);
						int Population = result.getInt(7);
						Float LifeExpectancy = result.getFloat(8);
						Float GNP = result.getFloat(9);
						Float GNPOld = result.getFloat(10);
						String LocalName = result.getString(11);
						String GovermentForm = result.getString(12);
						String HeadOfState = result.getString(13);
						int Capital = result.getInt(14);
						String Code2 = result.getString(15);

						System.out.println(Code + "\t" + Name + "\t" + Continent + "\t" + Region + "\t" + SurfaceArea
								+ "\t" + IndepYear + "\t" + Population + "\t" + LifeExpectancy + "\t" + GNP + "\t"
								+ GNPOld + "t" + LocalName + "\t" + GovermentForm + "\t" + HeadOfState + "\t" + Capital
								+ "\t" + Code2);
					} while (result.next());
				}
			} catch (SQLException | NullPointerException e) {
				System.out.println("Error while printing the city details: " + e);
			}
		} else {
			System.out.println("ResultSet null");
		}
	}

	public static ResultSet fetchAllCountryDetails() {
		ResultSet result = null;
		String sql = "SELECT * FROM country LIMIT ?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, 10);
			try {
				result = preparedStatement.executeQuery();
			} catch (SQLException e) {
				System.out.println("Error in the resultset " + e);
			}
		} catch (SQLException e) {
			System.out.println("Error obtaining an instance of the statement " + e);
		}
		return result;
	}

	/**
	 * Retrieves the details of one country by its code
	 * 
	 * @param String code
	 * @return ResultSet
	 */
	public static ResultSet fetchCountryDetailsByCode(String code) {
		ResultSet result = null;
		String sql = "SELECT * FROM country WHERE code = ?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, code);
			try {
				result = preparedStatement.executeQuery();
			} catch (SQLException e) {
				System.out.println("Error in the resultset " + e);
			}
		} catch (SQLException e) {
			System.out.println("Error obtaining an instance of the statement " + e);
		}
		return result;
	}

	public static int insertCountry(String Code, String Name, String Continent, String Region, Float SurfaceArea,
			int IndepYear, int Population, Float LifeExpectancy, Float GNP, Float GNPOld, String LocalName,
			String GovermentForm, String HeadOfState, int Capital, String Code2) {
		int rowsAffected = 0;
		String sql = "insert into country VALUES (?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, Code);
			statement.setString(2, Name);
			statement.setString(3, Continent);
			statement.setString(4, Region);
			statement.setFloat(5, SurfaceArea);
			statement.setInt(6, IndepYear);
			statement.setInt(7, Population);
			statement.setFloat(8, LifeExpectancy);
			statement.setFloat(9, GNP);
			statement.setFloat(10, GNPOld);
			statement.setString(11, LocalName);
			statement.setString(12, GovermentForm);
			statement.setString(13, HeadOfState);
			statement.setInt(14, Capital);
			statement.setString(15, Code2);

			try {
				rowsAffected = statement.executeUpdate();
			} catch (SQLException e) {
				System.out.println("Error during insertion " + e);
			}
		} catch (SQLException e) {
			System.out.println("Error obtaining an instance of the statement " + e);
		}
		return rowsAffected;
	}

	public static int[] updateCountry(String country, String code) {
		int[] rowsAffected = null;
		String sqlForUpdate = "UPDATE country SET Name = ? WHERE code = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(sqlForUpdate)) {
			preparedStatement.setString(1, country);
			preparedStatement.setString(2, code);
			preparedStatement.addBatch();
			preparedStatement.setString(1, "Aruba");
			preparedStatement.setString(2, "ABW");
			preparedStatement.addBatch();
			preparedStatement.setString(1, "Zimbabwe");
			preparedStatement.setString(2, "ZWE");
			preparedStatement.addBatch();

			try {
				rowsAffected = preparedStatement.executeBatch();
			} catch (SQLException e) {
				System.out.println("Error during insertion " + e);
			}
		} catch (SQLException e) {
			System.out.println("Error obtaining an instance of the statement " + e);
		}
		return rowsAffected;
	}

	public static int deleteCountry(String Code) {
		int rowsAffected = 0;

		String deleteSql = "DELETE FROM Country WHERE Code = ?";
		try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSql)) {
			preparedStatement.setString(1, Code);
			try {
				rowsAffected = preparedStatement.executeUpdate();
			} catch (SQLException e) {
				System.out.println("Error during insertion " + e);
			}
		} catch (SQLException e) {
			System.out.println("Error obtaining an instance of the statement " + e);
		}
		return rowsAffected;
	}
}
