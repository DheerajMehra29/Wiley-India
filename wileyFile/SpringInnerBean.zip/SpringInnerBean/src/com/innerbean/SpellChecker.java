package com.innerbean;

public class SpellChecker {
	public SpellChecker() {
		System.out.println("Inside SpellChecker constructor");
	}
	
	public void spellChecking() {
		System.out.println("Inside spellChecking");
	}
}
